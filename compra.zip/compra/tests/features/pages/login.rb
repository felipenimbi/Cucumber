# encoding: utf-8
# !/usr/bin/env ruby
require 'site_prism'

module Nimbi
  module Pages
    # PageObjets for Login
    class LoginPage < SitePrism::Page
      set_url '/'
      element :username, 'input[id$=wtUsernameField]'
      element :password, 'input[type=password]'
      element :go_login, 'input[value=Entrar]'

      def with(user, pwd)
        username.set user
        password.set pwd
        go_login.click
      end
    end
  end
end
