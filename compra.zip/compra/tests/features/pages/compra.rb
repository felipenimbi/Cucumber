# encoding: utf-8
# !/usr/bin/env ruby
require 'site_prism'

module Nimbi
  module Pages
    # My Requests
    class MyRequestsPage < SitePrism::Page
      element :filter, 'a[id$=Lnk_Notify]'
      element :request_menu, 'span[data-webbtests=\'MenuWB.expRequest\']'
      element :search_field_request, '.feTxt input[data-webbtests$=Fld_Search_Input]'
      element :btn_search_request, 'input[data-webbtests$=\'wblFormGenericSearchBoxBlock.btnOk\']' 
      element :title_req, 'span[data-webbtests^=\'CompraWeb.Request_List.wblLazyLoad.expProdutosdeLimpeza\']'
      element :btn_delete_req, '.Menu_TopMenu a[data-webbtests$=lnkDelete]'
      element :chk_box_req, 'input[data-webbtests^=\'CompraWeb.Request_List.wblLazyLoad.chkRequestSelected\']'  
      def filter_by(status)
        filter(text: status, match: :prefer_exact).click
      end
    end

    #Order

    class MyOrderPage < SitePrism::Page

      # VARIÁVEIS PAINEL GERAL ITEM

        element :title_order, 'span[data-webbtests$=\'Order_List2.wblLayout_ListEdit\']'
        element :new_title_order, 'input[data-webbtests$=inpTitleInp]'
        element :fornecedor_name, 'input[data-webbtests$=inpCompanyName0]' 
        element :fornecedor_autocomplete, '.os-internal-ui-menu-item .os-internal-ui-corner-all'
        element :doc_type_order, 'select[data-webbtests$=cboDocumentType]'
        element :delivery_order_type, 'select[id$=Cmb_IsAddressByRequest]'
        elements :dropdown_list_order, 'li[class$=result-selectable] div'
        element :btn_order_next, 'input[data-webbtests$=lblNext]'
        def select_order_delivery_type(txt)
          delivery_order_type.find('option', text: txt).select_option
        end

        def select_doc_type_order(txt)
          doc_type_order.find('option', text: txt).select_option
        end

      # VARIÁVEIS PAINEL ITEM E POP-ITEM CATALOGADO E NÃO CATALOGADO
        element :btn_create_item, 'span[data-webbtests$=lblActions]'
        element :btn_non_catalog_item, 'a[data-webbtests$=LknNonCatalogedItems]'
        element :short_descrip_item, 'input[data-webbtests$=divShortDescription]'
        element :delivery_date, 'input[id$=wtinpDelivaryDate]'
        element :unit, 'select[data-webbtests$=cboUnit]'
        element :unit_price, 'input[data-webbtests$=inpUnitPrice]'
        element :quantity, 'input[data-webbtests$=inpQuantity]'
        element :btn_category, 'a[data-webbtests$=lnkSelectCategory]'
        element :btn_save_item, 'input[data-webbtests$=btnResetPasswordCancel]'  

      # VARIAVEIS PAINEL ATRIBUTOS DE FRETE
        element :incoterm, 'select[data-webbtests$=cboIncoTerm]'

        def select_incoterm(txt)
          incoterm.find('option', text: txt).select_option
        end
    end    

    # Request
    class RequestPage < SitePrism::Page
      element :title, 'input[id$=TitleInp]'
      element :doc_type, 'div[id$=wtCmb_DocumentType]'
      element :priority, 'select[id$=Cmb_Priority]'
      element :delivery_type, 'select[id$=Cmb_IsAddressByRequest]'
      element :delivery_address, 'div[id$=Cmb_DeliveryAddress]'
      element :pay_address, 'div[id$=Cmb_PaymentAddress]'
      element :pay_type, 'div[id$=Cmb_PaymentType]'
      element :next_button, 'input[data-webbtests$=btnNext]'
      element :save_button, 'input[data-webbtests$=lblAttachmentsbtnSave]'
      element :req_code, 'span[data-webbtests$=expRequetOld]'

      elements :dropdown_list, 'li[class$=result-selectable] div'

      def select_priority(txt)
        priority.find('option', text: txt).select_option
      end

      def select_delivery_type(txt)
        delivery_type.find('option', text: txt).select_option
      end

      def select_doc_type(txt)
        doc_type.click
        sleep(3)
        dropdown_list.each do |x|
          if x.text == txt
            x.click
            break
          end
        end
      end

      def select_pay_type(txt)
        pay_type.click
        sleep(3)
        dropdown_list.each do |x|
          if x.text == txt
            x.click
            break
          end
        end
      end

    end
  end
end
