# encoding: utf-8
# !/usr/bin/env ruby
require 'site_prism'

module Nimbi
  module Pages
    # dashboard
    class DashboardPage < SitePrism::Page
      element :user_options, '.userOptions'
      element :tour, '.jTour_close a'
      element :feedback_message, '.Feedback_Message_Text'
    end
  end
end
