# encoding: utf-8
# !/usr/bin/env ruby
require 'site_prism'

module Nimbi
  module Pages
    # Menu principal
    class NavigationPage < SitePrism::Page
      element :title, '.pageTitle .tit01-1'
      element :title_order_list, 'span[data-webbtests$=wblLayout_ListEdit]'
      element :title_create_order, 'span[data-webbtests$=\'wblMain.lblCreateOrder\']'
      element :side_menu, '.Menu_TopMenus div[id$=wtMenuItem]'
      element :menu_order, 'a[data-webbtests$=lnkMenuOrder]'
      element :side_submenu, '.menu-item'
      element :top_menu, '.searchCreateBox .Menu_TopMenu span'
      element :top_submenu, '.searchCreateBox .SubMenu_TopMenu span'
      element :top_create_new, 'span[data-webbtests$=lblCreateNew]'
      element :top_sub_new_req, 'span[data-webbtests$=lblRequest'
      element :top_sub_new_order, 'a[data-webbtests$=\'wblDropDownMenu.lnkOrder\']'
      element :menu_config_compra, 'a[data-webbtests$=lnkCompraWeb]'
      element :menu_list_of_value_compra, 'a[data-webbtests$=lnkListOfValues2]'
      element :btn_add_categ_contabil, 'input[data-webbtests$=btnAdd]'
      element :title_pop_up_cat, 'span[id=os-internal-ui-dialog-title-1]'
      element :field_input_code, 'form[id$=WebForm1] input[id$=wtFld_Code]'
      element :field_input_descri, '.popup_page input[id$=wtFld_Description]'
      element :field_select_status, 'form[id$=WebForm1] select[id$=wtCmb_Status]'
      element :btn_save_cat_contab, 'input[value=Salvar]'
      element :btn_next, '.ListNavigation_Next'
      
      def find_categ_contab(txt1)
        page.all('.TableRecords', text: txt1).click
      end

      def select_list_of_values
        page.find('.a04-1-1', text: "Lista de valores").click
      end


      def select_status(txt)
        field_select_status.find('option', text: txt).select_option
      end

    end
  end
end

