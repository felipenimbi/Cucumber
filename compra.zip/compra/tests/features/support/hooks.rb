# encoding: utf-8
# !/usr/bin/env ruby

require_relative 'helper.rb'
require_relative 'spec_helper.rb'
World(Nimbi::Pages)
World(Capybara::DSL)

Before do |_feature|
  ## configure the chosen browser
  Capybara.configure do |config|
    config.default_max_wait_time = 60
    config.default_driver = :selenium
    config.javascript_driver = :selenium
    config.app_host = CONFIG['url']
  end

  ## set default max wait and maximize browser
  Capybara.default_max_wait_time = 30
  unless BROWSER.eql?('poltergeist')
    Capybara.current_session.driver.browser.manage.window.maximize
  end
end

After do |scenario|
  @helper = Helper.new
  ## take screenshot if scenario fail
  if scenario.failed?
    @helper.take_screenshot(scenario.name, 'screenshots/test_failed')
  end
end

After do |feature|
  if feature.source_tag_names.include?('@background')
    Capybara.current_session.driver.quit unless BROWSER.eql?('poltergeist')
  end
end
