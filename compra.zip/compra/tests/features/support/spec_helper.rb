# encoding: utf-8
# !/usr/bin/env ruby

Dir[File.join(File.dirname(__FILE__), '../pages/*.rb')].each { |file| require file }

module Nimbi
  # Instanciando todas as paginas
  module Pages
    def login
      Nimbi::Pages::LoginPage.new
    end

    def dashboard
      Nimbi::Pages::DashboardPage.new
    end

    def nav
      Nimbi::Pages::NavigationPage.new
    end

    def settings
      Nimbi::Pages::SettingsPage.new
    end

    def my_requests
      Nimbi::Pages::MyRequestsPage.new
    end

    def my_orders
      Nimbi::Pages::MyOrderPage.new
    end
     
    def request
      Nimbi::Pages::RequestPage.new
    end
  end
end

