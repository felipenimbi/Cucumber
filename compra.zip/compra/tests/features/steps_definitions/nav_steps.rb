# encoding: utf-8
# !/usr/bin/env ruby

E(/^clique no menu lateral "([^"]*)"$/) do |mod|
  nav.side_menu(text: mod, match: :prefer_exact).click
end

Given(/^Abre a página "([^"]*)"$/) do |pag|
  nav.side_submenu(text: pag, match: :prefer_exact).click
end

Dado(/^que o usuário tenha visibilidate do menu Pedidos$/) do
  expect(page).to have_text 'Pedidos'
end

E (/^clique no submenu lateral "([^"]*)"$/) do |ord|
   nav.menu_order(text: ord, match: :prefer_exact).click
end

Então(/^Deve exibir a página de pedidos "([^"]*)"$/) do |page|
  nav.title_order_list.text.should eq UnicodeUtils.upcase(page)
  page.instance_variable_set(:@touched, false)
end

Quando(/^eu clicar no botão Criar Novo$/) do
  nav.top_create_new.click
end

Given(/^Em seguida clica em Requisição$/) do
  nav.top_sub_new_req.click
end

Quando(/^eu clicar no botão Criar Novo > Pedido$/) do
  nav.top_create_new.click
  sleep(1)
  nav.top_sub_new_order.click
end

Então(/^vejo a página "([^"]*)"$/) do |page_order|
  nav.title_create_order.text.should eq UnicodeUtils.upcase(page_order)
end



