# encoding: utf-8
# !/usr/bin/env ruby

Given(/^Usuario acessa uma Requisição com status "([^"]*)"$/) do |_arg1|
  my_requests.filter
end

Given(/^Preenche o formulário de Requisição$/) do |table|
  table.hashes.each do |col|
    $req_name = col['titulo'] + " #{Faker::Commerce.product_name}"
    puts "Criando a Req #{$req_name}"
    request.title.set $req_name
    request.select_priority(col['prioridade'])
    request.select_doc_type(col['tp_doc'])
    request.select_delivery_type(col['tp_entrega'])
  end
end

Given(/^Salva o formuário de Requisicão$/) do
  request.save_button.click if request.has_save_button?
  request.next_button.click if request.has_next_button?
end

Given(/^E o código da requisição deve ser maior que zero$/) do
  request.req_code.text.to_i.should be > 0
end

Given(/^Escolhe um endereço de entrega$/) do
  request.delivery_address.click
  sleep(1)
  request.dropdown_list.sample.click
end

Given(/^Escolhe um endereço de Faturamento$/) do
  request.pay_address.click
  sleep(1)
  request.dropdown_list.sample.click
end

Given(/^Seleciona a forma de pagamento "([^"]*)"$/) do |payment|
  request.select_pay_type(payment)
end
