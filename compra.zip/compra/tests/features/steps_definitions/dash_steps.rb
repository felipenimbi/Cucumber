# encoding: utf-8
# !/usr/bin/env ruby

Então(/^Deve exibir a mensagem "([^"]*)"$/) do |msg|
  dashboard.feedback_message.should have_text msg
end