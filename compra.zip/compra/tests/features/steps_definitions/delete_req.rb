# encoding: utf-8
# !/usr/bin/env ruby

Given(/^Seleciono a checkbox da requisição$/) do
  sleep(1)
  my_requests.chk_box_req.click
end

Given(/^Clico no botão Excluir$/) do
  sleep(2)
  my_requests.btn_delete_req.click
end                                                                         

