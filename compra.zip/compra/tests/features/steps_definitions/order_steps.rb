# encoding: utf-8
# !/usr/bin/env ruby

E (/^informar todos os campos do painel Geral$/) do |table|

    @order_name = Faker::Commerce.product_name
    my_orders.new_title_order.set @order_name
    table.hashes.each do |col|
     my_orders.fornecedor_name.set(col['fornecedor'])
     sleep(3)
     my_orders.fornecedor_autocomplete.click
     my_orders.select_doc_type_order(col['tp_doc'])
     my_orders.select_order_delivery_type(col['dados_entrega'])
  end
end

E (/^clicar em Próximo$/) do
    my_orders.btn_order_next.click
end

# Dado (/^que o usuário clique no botão Criar Novo > Item Não Catalogado$/) do
#   my_orders.btn_create_item.click
#   sleep(1)
#   my_orders.btn_non_catalog_item.click
# end

# INSERIR ITEM NÃO CATALOGADO NO PEDIDO
Dado (/^que meu pedido possua 1 item não catalogado$/) do |table|

my_orders.btn_create_item.click
  sleep(1)
my_orders.btn_non_catalog_item.click

table.hashes.each do |tab|
  within_frame(page.find('iframe')) do
    
  @quantity = table.hashes[0]['quantidade']
  @deliv_date = table.hashes[0]['data_entrega']
  @unity = table.hashes[0]['unidade']
  @unit_price = table.hashes[0]['preco_unitario']
  @short_descr = Faker::Lorem.word

  my_orders.short_descrip_item.set @short_descr
  my_orders.quantity.set "#{@quantity}"
  sleep(1)
  my_orders.unit.first('option', text: @unity).click
  sleep(1)
  my_orders.delivery_date.set "#{@deliv_date}"
  sleep(1)
  my_orders.unit_price.set "#{@unit_price}"
  sleep(1)
  my_orders.btn_category.click
  sleep(2)
  my_orders.first("input[type='radio']").click
  sleep(5)
  my_orders.btn_save_item.click
  sleep(2)
   end
  msg = find('.Feedback_Message_Text').text
  msg.should eq 'Item salvo com sucesso' 
end
end

E (/^painel dados de entrega e faturamento preenchidos$/) do
  request.delivery_address.click
  sleep(1)
  request.dropdown_list.sample.click
  sleep(1)
  request.pay_address.click
  sleep(1)
  request.dropdown_list.sample.click
  sleep(1)
  request.pay_type.click
  sleep(1)
  request.dropdown_list.sample.click
end

E (/^painel de atributos de frete preenchidos$/) do |table|
  table.hashes.each do |tab1|
  my_orders.select_incoterm(tab1['incoterm'])
   end
end







