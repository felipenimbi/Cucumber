# encoding: utf-8
# !/usr/bin/env ruby

Dado(/^que eu esteja logado como "([^"]*)"$/) do |arg1|
  login.load
  login.with('ebiz.testeos+comprcomprador01@webb.com.br', 'Webb123!')
  # dashboard.tour.click
end
