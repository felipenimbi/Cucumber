# encoding: utf-8
# !/usr/bin/env ruby
Given(/^Acessa menu requisições através de uma requisição$/) do
  my_requests.request_menu.click
end

Given(/^Pesquiso por uma requisição$/) do
  sleep(2)
  @title_req = $req_name
  my_requests.search_field_request.set @title_req
end

Given(/^Verifico se o resultado é o pesquisado$/) do
  my_requests.btn_search_request.click
  sleep(2)
  my_requests.title_req.should have_text (@title_req)
end  