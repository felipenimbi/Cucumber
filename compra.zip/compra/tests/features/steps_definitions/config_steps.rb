# encoding: utf-8
# !/usr/bin/env ruby

E(/^clico no menu lateral Compra$/) do 
  nav.menu_config_compra.click
end

Então(/^vejo o Dashboard do Compra$/) do                                               
  expect(page).to have_title 'Dashboard'
end 

Given(/^Clica na opção Lista de valores$/) do 
  nav.select_list_of_values
end

Given(/^Clica em adicionar$/) do 
 nav.btn_add_categ_contabil.click
end

Given(/^Vejo o pop-up "([^"]*)"$/) do |title|
 nav.title_pop_up_cat.should equal? UnicodeUtils.upcase(title)
end

Given(/^Cadastra a categoria contabil ativa$/) do |table_config|
sleep(1)
table_config.hashes.each do |col|
  within_frame(page.find('iframe')) do
     within('#WebForm1') do
      @cod_category = col['codigo'] + " #{Faker::Code.asin}"
      @descr_category = col['descricao'] + "#{Faker::Lorem.characters(10)}"
      nav.field_input_code.set @cod_category
      nav.field_input_descri.set @descr_category
      nav.select_status(col['status']) 
      nav.btn_save_cat_contab.click
     end
   end
 end
end

Given(/^Exclui a categoria contábil$/) do
 
   page.all('.TableRecords tr').each do |ele| 
   @tot = page.all('.TableRecords_OddLine a').count
   @tot1 = page.all('.TableRecords_EvenLine a').count
   @tot_page = @tot + @tot1

#    puts (@tot_page)
#     until ele.@tot_page < 12 do  
#      if ele.text == @descr_category
#         ele.click    
#       else
#         nav.btn_next.click
#      end
#  end
end
end
 






