## Getting Started ##

### Installing rbenv ###
To install rbenv type:
```shell
brew install rbenv
```

Add to ~/.bash_profile:
```shell
eval "$(rbenv init -)"
```

List all available versions:
```shell
rbenv install -l
```

Install a Ruby version:
```shell
rbenv install 2.3.1
```

Sets a local application-specific Ruby 2.3.1:
```shell
rbenv local 2.3.1
```

### Installing bundler ###
To install bundler type:
```shell
gem install bundler
```

### Windows ###

##### Install FFI #####

To install FFI package type:
```shell
bundle install ffi --platform ruby
```

### Installing gems ###
To install gems type:
```shell
bundle install
```

### Drivers: ###
Install and include in PATH
- [chromedriver](https://sites.google.com/a/chromium.org/chromedriver/)
- [phantomjs](http://phantomjs.org/)


### Run tests in ENV with BROWSER###
Type this in the tests folder:
```shell
bundle exec cucumber -p BROWSER -p ENV
```

### HTML Report###
Type this in the tests folder:
```shell
bundle exec cucumber -p html_report
```

### Run with tags###
Type this in the tests folder:
```shell
bundle exec cucumber --tags @run
```
